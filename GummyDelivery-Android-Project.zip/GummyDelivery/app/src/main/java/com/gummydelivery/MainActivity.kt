package com.gummydelivery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF20A66A)
private val Dark = Color(0xFF20232B)
private val Muted = Color(0xFF737985)
private val PaleGreen = Color(0xFFE9F8EF)
private val Coral = Color(0xFFFF745F)
private val Yellow = Color(0xFFFFC45B)
private val Blue = Color(0xFF5799E8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GummyDeliveryApp() }
    }
}

@Composable
fun GummyDeliveryApp() {
    var page by remember { mutableStateOf("welcome") }
    var demoCodeShown by remember { mutableStateOf(false) }
    var enteredCode by remember { mutableStateOf("") }
    var cartCount by remember { mutableIntStateOf(0) }
    var payment by remember { mutableStateOf("GummyCard") }
    var distance by remember { mutableIntStateOf(18) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            secondary = Coral,
            background = Color(0xFFF7F8FA),
            surface = Color.White
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFFF7F8FA)) {
            when (page) {
                "welcome" -> WelcomeScreen(onContinue = { page = "login" })
                "login" -> LoginScreen(
                    codeShown = demoCodeShown,
                    enteredCode = enteredCode,
                    onCodeChange = { enteredCode = it },
                    onGenerate = { demoCodeShown = true },
                    onVerify = {
                        if (enteredCode == "246810") page = "home"
                    },
                    onBack = { page = "welcome" }
                )
                "home" -> HomeScreen(
                    cartCount = cartCount,
                    onAdd = { cartCount++ },
                    onCart = { page = "cart" }
                )
                "cart" -> CartScreen(
                    count = cartCount,
                    onBack = { page = "home" },
                    onRemove = { if (cartCount > 0) cartCount-- },
                    onCheckout = { if (cartCount > 0) page = "payment" }
                )
                "payment" -> PaymentScreen(
                    selected = payment,
                    onSelect = { payment = it },
                    onBack = { page = "cart" },
                    onPay = { page = "tracking"; distance = 18 }
                )
                "tracking" -> TrackingScreen(
                    distance = distance,
                    onStep = {
                        if (distance > 0) distance = (distance - 3).coerceAtLeast(0)
                    },
                    onFinish = { page = "success" }
                )
                else -> SuccessScreen(onHome = {
                    cartCount = 0
                    page = "home"
                })
            }
        }
    }
}

@Composable
fun WelcomeScreen(onContinue: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(104.dp).background(PaleGreen, RoundedCornerShape(30.dp)),
            contentAlignment = Alignment.Center
        ) { Text("🍔", fontSize = 54.sp) }
        Spacer(Modifier.height(22.dp))
        Text("GummyDelivery", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = Dark)
        Text("Antojos a tu manera.", color = Muted, fontSize = 16.sp)
        Spacer(Modifier.height(34.dp))
        Button(
            onClick = onContinue,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(18.dp)
        ) { Text("Comenzar", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(12.dp))
        Text("Una experiencia de pedidos completamente ficticia.", color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun LoginScreen(
    codeShown: Boolean,
    enteredCode: String,
    onCodeChange: (String) -> Unit,
    onGenerate: () -> Unit,
    onVerify: () -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Volver") }
        Text("¡Qué onda!", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Dark)
        Text("Inicia sesión en modo demostración.", color = Muted)
        Spacer(Modifier.height(24.dp))
        Text("Número de prueba (no se envía)", fontWeight = FontWeight.SemiBold)
        OutlinedTextField(
            value = "000 000 0000",
            onValueChange = {},
            enabled = false,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        )
        Spacer(Modifier.height(12.dp))
        if (!codeShown) {
            Button(onClick = onGenerate, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Text("Generar código de demostración")
            }
        } else {
            Card(colors = CardDefaults.cardColors(containerColor = PaleGreen)) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Text("Tu código de prueba es", color = Muted, fontSize = 12.sp)
                    Text("246810", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Green)
                    Text("Este código aparece aquí; no se envía por SMS.", color = Muted, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = enteredCode,
                onValueChange = { onCodeChange(it.take(6)) },
                label = { Text("Introduce el código") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = onVerify, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Text("Verificar e ingresar")
            }
            if (enteredCode.isNotEmpty() && enteredCode != "246810") {
                Text("Código incorrecto. Prueba el código mostrado arriba.", color = Coral, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun HomeScreen(cartCount: Int, onAdd: () -> Unit, onCart: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("GummyDelivery", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Dark)
                Text("¿Qué se te antoja hoy?", color = Muted)
            }
            BadgedBox(badge = { if (cartCount > 0) Badge { Text(cartCount.toString()) } }) {
                IconButton(onClick = onCart) { Icon(Icons.Default.ShoppingCart, contentDescription = "Carrito", tint = Green) }
            }
        }
        LazyColumn(contentPadding = PaddingValues(horizontal = 18.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F3FF)), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp)) {
                        Text("ANTOJO DEL DÍA", color = Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("Hoy se come rico.", color = Dark, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Text("Descubre sabores de nuestro universo.", color = Muted)
                    }
                }
            }
            item {
                Text("Restaurantes populares", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Dark)
            }
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(66.dp).background(Color(0xFFFFE8E5), RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                                Text("🍔", fontSize = 38.sp)
                            }
                            Spacer(Modifier.width(13.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Wac Donals", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Dark)
                                Text("Hamburguesas • Papas • Bebidas", fontSize = 12.sp, color = Muted)
                                Text("★ 4.8  ·  20–30 min", fontSize = 12.sp, color = Green)
                            }
                        }
                        Spacer(Modifier.height(15.dp))
                        HorizontalDivider(color = Color(0xFFF0F1F3))
                        Spacer(Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Wac Doble Clásica", fontWeight = FontWeight.Bold, color = Dark)
                                Text("Doble carne, queso y salsa especial.", fontSize = 12.sp, color = Muted)
                                Text("$89.00", color = Green, fontWeight = FontWeight.Bold)
                            }
                            Button(onClick = onAdd, shape = RoundedCornerShape(14.dp)) { Text("+ Agregar") }
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Papas Wac", fontWeight = FontWeight.Bold, color = Dark)
                                Text("Papas crujientes.", fontSize = 12.sp, color = Muted)
                                Text("$39.00", color = Green, fontWeight = FontWeight.Bold)
                            }
                            Button(onClick = onAdd, shape = RoundedCornerShape(14.dp)) { Text("+ Agregar") }
                        }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF0D7)), shape = RoundedCornerShape(20.dp)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🥤", fontSize = 34.sp)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Me-picalaCola", color = Color(0xFF9A5B13), fontWeight = FontWeight.Bold)
                            Text("El refresco oficial de los antojos.", color = Color(0xFF9A5B13), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        NavigationBar(containerColor = Color.White) {
            NavigationBarItem(selected = true, onClick = {}, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Inicio") })
            NavigationBarItem(selected = false, onClick = onCart, icon = { Icon(Icons.Default.ShoppingCart, null) }, label = { Text("Carrito") })
            NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Default.Storefront, null) }, label = { Text("Tiendas") })
        }
    }
}

@Composable
fun CartScreen(count: Int, onBack: () -> Unit, onRemove: () -> Unit, onCheckout: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
        Text("Tu carrito", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Dark)
        Spacer(Modifier.height(18.dp))
        if (count == 0) {
            Text("Tu carrito está vacío. ¡Agrega algo rico!", color = Muted)
        } else {
            Card(shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("Wac Donals", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("$89.00 × $count artículo(s)", color = Muted)
                    Text("Total: \$${89 * count}.00", color = Green, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    TextButton(onClick = onRemove) { Text("Quitar un artículo") }
                }
            }
            Spacer(Modifier.height(18.dp))
            Button(onClick = onCheckout, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
                Text("Continuar al pago")
            }
        }
    }
}

@Composable
fun PaymentScreen(selected: String, onSelect: (String) -> Unit, onBack: () -> Unit, onPay: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
        Text("GummyPay", fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, color = Dark)
        Text("Elige un método de pago de demostración.", color = Muted)
        Spacer(Modifier.height(22.dp))
        listOf("GummyCard", "PayPapu", "Efectivo Gummy").forEach { method ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable { onSelect(method) },
                colors = CardDefaults.cardColors(containerColor = if (selected == method) PaleGreen else Color.White),
                shape = RoundedCornerShape(18.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected == method, onClick = { onSelect(method) })
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(method, fontWeight = FontWeight.Bold, color = Dark)
                        Text("Método ficticio · Sin cargos reales", fontSize = 11.sp, color = Muted)
                    }
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Button(onClick = onPay, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
            Text("Pagar pedido de prueba")
        }
        Text("Los pagos se aprueban localmente y no se solicitan datos bancarios.", fontSize = 11.sp, color = Muted, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable
fun TrackingScreen(distance: Int, onStep: () -> Unit, onFinish: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Color.White).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(26.dp))
        Text("Llegando a tu destino", color = Dark, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        Text("${distance} m", fontSize = 48.sp, fontWeight = FontWeight.ExtraBold, color = Dark)
        Text("Distancia de demostración hasta tu puerta", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.weight(1f))
        Box(
            Modifier.fillMaxWidth().weight(2f).background(Color(0xFFF5F6F7), RoundedCornerShape(28.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.ArrowUpward, contentDescription = "Dirección", tint = Dark, modifier = Modifier.size(100.dp))
                Spacer(Modifier.height(18.dp))
                Icon(Icons.Default.LocationOn, contentDescription = "Destino", tint = Green, modifier = Modifier.size(42.dp))
                Text("Tu puerta está adelante", color = Dark, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.weight(1f))
        if (distance > 0) {
            Button(onClick = onStep, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                Text("Simular que me acerco")
            }
            Text("La navegación de esta versión es simulada.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
        } else {
            Button(onClick = onFinish, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                Text("Ya llegué a mi puerta")
            }
        }
    }
}

@Composable
fun SuccessScreen(onHome: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(26.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Green, modifier = Modifier.size(88.dp))
        Spacer(Modifier.height(18.dp))
        Text("¡Pedido recogido con éxito!", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Dark, textAlign = TextAlign.Center)
        Text("Gracias por probar GummyDelivery.", color = Muted, textAlign = TextAlign.Center)
        Spacer(Modifier.height(28.dp))
        Button(onClick = onHome, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
            Text("Volver al inicio")
        }
    }
}
