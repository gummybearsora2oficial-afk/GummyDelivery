# GummyDelivery

Aplicación Android de demostración para pedidos ficticios.

## Incluye en esta primera versión
- Inicio de sesión local con código de prueba `246810` (no se envía SMS).
- Restaurante ficticio Wac Donals.
- Productos de demostración, como Me-picalaCola.
- Carrito de compras.
- GummyPay con métodos ficticios y sin cargos reales.
- Seguimiento de entrega simulado con flecha y contador.
- Confirmación «¡Pedido recogido con éxito!».

## Compilar
El repositorio incluye GitHub Actions. Sube el contenido de este proyecto a la raíz de un repositorio y ejecuta el workflow **Build GummyDelivery APK** desde la pestaña Actions.

El APK se publica como artifact llamado `GummyDelivery-APK`.

## Importante
Esta versión no envía SMS, no procesa pagos, no solicita ubicación real y no realiza entregas. El contador de distancia es una simulación interactiva.
